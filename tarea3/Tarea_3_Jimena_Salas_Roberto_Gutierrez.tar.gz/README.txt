#Instituto Tecnológico de Costa Rica
#Escuela de Ingeniería Electrónica
#Prof: Pablo Alvarado Moya
#Tarea 3 IRP
#Jimena Salas Alfaro, carné 2016085746
#Roberto Gutiérrez Sánchez, carné 2016134351
#09 de Setiembre, 2019

Instrucciones para ejecutar el script:

1. Ejecutar la terminal de Octave:
	
	$ octave-cli

2. Ejecutar dentro de la terminal de Octave el comando:
  
  $ tarea_3

3. Posteriormente se mostrarán las figuras generadas a partir de la regresión lineal y ponderada localmente.
